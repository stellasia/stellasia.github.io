# -*- coding: utf-8 -*-
"""Image classification. User submit an image from a simple form. Program returns its estimated class with best probability.

- Dependencies: python3, python3-virtualenv
- Usage:
    - First time

        # create virtualenv
        virtualenv -p /usr/bin/python3 venv
        # activate it
        source venv/bin/activate
        # install required python packages
        pip install requirements.txt
  
    - Every times

        flask run

"""
import os
import numpy as np

from PIL import Image

from flask import Flask, render_template, request, jsonify
from flask_uploads import UploadSet, configure_uploads, IMAGES


app = Flask(__name__)
images_upload_set = UploadSet('images', IMAGES)
app.config['UPLOADED_IMAGES_DEST'] = 'tmp_files'
configure_uploads(app, images_upload_set)


def analyze_file(f):
    # save image on disk in tmp location
    filename = images_upload_set.save(f)
    # get full image path on local disk
    file_path = images_upload_set.path(filename)
    # do things with image...
    # e.g. here, transform to numpy array through PIL
    im = Image.open(file_path)
    im2arr = np.array(im) # im2arr.shape: height x width x channel
    # remove temporary file
    os.remove(file_path)
    return {
        "name": filename,
        "shape": im2arr.shape,
        }

@app.route('/classify', methods=['GET', 'POST'])
def classify():
    if request.method == 'POST':
        if 'image' not in request.files:
            return render_template('index.html', error="Please select at least one image")
        # form does have images
        uploaded_files = request.files.getlist("image")
        result = []
        for f in uploaded_files:
            d = analyze_file(f)
            result.append(d)
        # return json response
        return jsonify(result)
    # if method == GET or no image in POST data
    # render the html form
    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True)
